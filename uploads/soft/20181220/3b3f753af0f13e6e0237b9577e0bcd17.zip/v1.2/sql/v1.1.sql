/*
Navicat MySQL Data Transfer

Source Server         : www.lvxing1788.com
Source Server Version : 50554
Source Host           : 119.23.214.59:3306
Source Database       : eyoucms_v1.0

Target Server Type    : MYSQL
Target Server Version : 50554
File Encoding         : 65001

Date: 2018-04-28 16:36:37
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for eyou_install_log
-- ----------------------------
DROP TABLE IF EXISTS `eyou_install_log`;
CREATE TABLE `eyou_install_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(50) DEFAULT '' COMMENT '用户域名',
  `last_domain` varchar(50) DEFAULT '',
  `key_num` varchar(10) DEFAULT '' COMMENT '用户版本号',
  `install_time` int(11) DEFAULT '0' COMMENT 'CMS安装时间',
  `serial_number` varchar(50) DEFAULT '' COMMENT '序列号',
  `ip` varchar(20) DEFAULT '' COMMENT '服务器IP',
  `phpv` varchar(20) DEFAULT '' COMMENT 'php版本',
  `mysql_version` varchar(20) DEFAULT '' COMMENT 'mysql版本',
  `web_server` varchar(20) DEFAULT '' COMMENT '服务器环境',
  `country` varchar(10) DEFAULT '' COMMENT '国家',
  `province` varchar(20) DEFAULT '' COMMENT '省份',
  `city` varchar(20) DEFAULT '' COMMENT '城市',
  `add_time` int(11) DEFAULT '0' COMMENT '新增时间',
  `update_time` int(11) DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of eyou_install_log
-- ----------------------------
INSERT INTO `eyou_install_log` VALUES ('15', 'demo.eyoucms.dev', 'demo.eyoucms.dev', 'v1.0.0', '1495257240', '20170520131400oCWIoa', '119.23.214.59', '5.4.45', '5.5.53', 'nginx/1.11.5', '中国', '广东', '深圳', '1524896286', '0');
INSERT INTO `eyou_install_log` VALUES ('16', 'demo.eyoucms.dev', 'demo.eyoucms.dev', 'v1.0.0', '1495257240', '20170520131400oCWIoa', '119.23.214.59', '5.4.45', '5.5.53', 'nginx/1.11.5', '中国', '广东', '深圳', '1524896291', '0');
INSERT INTO `eyou_install_log` VALUES ('17', 'demo.eyoucms.dev', 'demo.eyoucms.dev', 'v1.0.0', '1495257240', '20170520131400oCWIoa', '119.23.214.59', '5.4.45', '5.5.53', 'nginx/1.11.5', '中国', '广东', '深圳', '1524896293', '0');
INSERT INTO `eyou_install_log` VALUES ('18', 'demo.eyoucms.dev', 'demo.eyoucms.dev', 'v1.0.0', '1495257240', '20170520131400oCWIoa', '119.23.214.59', '5.4.45', '5.5.53', 'nginx/1.11.5', '中国', '广东', '深圳', '1524896329', '0');
INSERT INTO `eyou_install_log` VALUES ('19', 'demo.eyoucms.dev', 'demo.eyoucms.dev', 'v1.0.0', '1495257240', '20170520131400oCWIoa', '119.23.214.59', '5.4.45', '5.5.53', 'nginx/1.11.5', '中国', '广东', '深圳', '1524896337', '0');
INSERT INTO `eyou_install_log` VALUES ('20', 'demo.eyoucms.dev', 'demo.eyoucms.dev', 'v1.0.0', '1495257240', '20170520131400oCWIoa', '127.0.0.1', '5.4.45', '5.5.53', 'nginx/1.11.5', '', '', '', '1524897745', '0');
INSERT INTO `eyou_install_log` VALUES ('21', 'demo.eyoucms.dev', 'demo.eyoucms.dev', 'v1.0.0', '1495257240', '20170520131400oCWIoa', '127.0.0.1', '5.4.45', '5.5.53', 'nginx/1.11.5', '', '', '', '1524897745', '0');
INSERT INTO `eyou_install_log` VALUES ('22', 'demo.eyoucms.dev', 'demo.eyoucms.dev', 'v1.0.0', '1495257240', '20170520131400oCWIoa', '127.0.0.1', '5.4.45', '5.5.53', 'nginx/1.11.5', '', '', '', '1524897750', '0');
INSERT INTO `eyou_install_log` VALUES ('23', 'demo.eyoucms.dev', 'demo.eyoucms.dev', 'v1.0.0', '1495257240', '20170520131400oCWIoa', '127.0.0.1', '5.4.45', '5.5.53', 'nginx/1.11.5', '', '', '', '1524897759', '0');
INSERT INTO `eyou_install_log` VALUES ('24', 'eyoucms.lvxing1788.com', 'eyoucms.lvxing1788.com', '', '1495257240', '20170520131400oCWIoa', '119.23.214.59', '5.6.30', '5.5.54', 'Apache', '', '', '', '1524899793', '0');
INSERT INTO `eyou_install_log` VALUES ('25', 'eyoucms.lvxing1788.com', 'eyoucms.lvxing1788.com', '', '1495257240', '20170520131400oCWIoa', '119.23.214.59', '5.6.30', '5.5.54', 'Apache', '', '', '', '1524899794', '0');

-- ----------------------------
-- Table structure for eyou_upgrade_log
-- ----------------------------
DROP TABLE IF EXISTS `eyou_upgrade_log`;
CREATE TABLE `eyou_upgrade_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(50) DEFAULT '' COMMENT '用户域名',
  `key_num` varchar(10) DEFAULT '' COMMENT '用户版本号',
  `to_key_num` varchar(10) DEFAULT '' COMMENT '用户要升级的版本号',
  `serial_number` varchar(50) DEFAULT '' COMMENT '序列号',
  `ip` varchar(20) DEFAULT '' COMMENT '用户IP',
  `phpv` varchar(20) DEFAULT '' COMMENT 'php版本',
  `mysql_version` varchar(20) DEFAULT '' COMMENT 'mysql版本',
  `web_server` varchar(20) DEFAULT '' COMMENT '服务器环境',
  `add_time` int(11) DEFAULT '0' COMMENT '升级时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of eyou_upgrade_log
-- ----------------------------

-- ----------------------------
-- Table structure for eyou_upgradepackage
-- ----------------------------
DROP TABLE IF EXISTS `eyou_upgradepackage`;
CREATE TABLE `eyou_upgradepackage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key_num` varchar(20) DEFAULT '' COMMENT '更新包版本号',
  `down_url` varchar(255) DEFAULT '' COMMENT '下载地址',
  `file_md5` varchar(100) DEFAULT '',
  `sql_file` text COMMENT '数据库升级包',
  `prompt1` varchar(255) DEFAULT '' COMMENT '升级提示语',
  `prompt2` text COMMENT '升级提示需要覆盖哪些文件',
  `add_time` int(11) DEFAULT '0' COMMENT '新增时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of eyou_upgradepackage
-- ----------------------------
INSERT INTO `eyou_upgradepackage` VALUES ('1', 'v1.0.1', 'http://eyoucms.lvxing1788.com/v1.0.1.zip', '68f3b5765bad8eed9040190b08673a8b', '{\"v1.0.1\":\"v1.0.2.sql\",\"v1.0.2\":\"v1.0.3.sql\",\"v1.0.3\":\"v1.0.4.sql\"}', '你的系统不是最新的,一键升级到v1.0.1', '升级将覆盖以下文件, 请确保备份好文件再升级\r\ntemplate/pc/rainbow/cart/cart2.html\r\napplication/admin/conf/version.php\r\napplication/common/logic/MessageLogic.php\r\napplication/common.php\r\napplication/admin/logic/FlashSaleLogic.php\r\napplication/admin/logic/GroupBuyLogic.php\r\napplication/admin/logic/PromGoodsLogic.php\r\napplication/api/controller/Goods.php\r\napplication/common/logic/ActivityLogic.php\r\napplication/common/logic/CouponLogic.php\r\napplication/home/controller/Goods.php\r\napplication/home/logic/CartLogic.php\r\napplication/mobile/controller/Goods.php\r\ntemplate/app/default/user/points_list.html\r\ntemplate/mobile/new2/static/css/style.css\r\napplication/home/controller/Index.php\r\napplication/mobile/controller/Distribut.php\r\napplication/admin/controller/Ueditor.php\r\napplication/common/logic/WechatLogic.php\r\napplication/common/util/WechatUtil.php\r\napplication/home/controller/Api.php\r\napplication/admin/controller/Wechat.php\r\napplication/admin/view2/system/distribut.html\r\napplication/admin/view2/wechat/setting.html\r\napplication/admin/view2/system/oss.html\r\napplication/admin/view2/system/water.html\r\napplication/common/logic/OssLogic.php\r\napplication/function.php\r\nvendor/aliyun-oss-php-sdk\r\nplugins/payment/weixin/config.php\r\nplugins/payment/weixin/weixin.class.php\r\napplication/home/controller/Activity.php\r\ntemplate/mobile/new2/activity/coupon_list.html\r\napplication/admin/conf/menu.php\r\napplication/admin/controller/MobileApp.php\r\napplication/admin/controller/System.php\r\napplication/admin/view2/mobile_app\r\napplication/admin/view2/mobile_app/index.html\r\napplication/api/controller/App.php\r\napplication/api/controller/Cart.php\r\napplication/api/controller/Payment.php\r\napplication/home/logic/GoodsLogic.php\r\npublic/plugins/Ueditor/third-party/webuploader/webuploader.min.js\r\npublic/plugins/Ueditor/ueditor.all.min.js\r\npublic/plugins/webuploader/webuploader.min.js\r\nplugins/payment/alipay/alipay.class.php\r\ntemplate/pc/rainbow/order/order_list.html\r\ntemplate/pc/rainbow/user/order_list.html\r\napplication/admin/controller/Order.php\r\napplication/admin/view2/order/ajaxindex.html\r\napplication/admin/view2/order/refund_order_info.html\r\napplication/admin/view2/order/refund_order_list.html\r\napplication/admin/view2/order/return_info.html\r\napplication/config.php\r\ntemplate/pc/rainbow/goods/goodsList.html\r\ntemplate/pc/rainbow/public/header.html\r\ntemplate/pc/rainbow/static/css/tpshop.css\r\ntemplate/pc/rainbow/static/sass/_skip.scss\r\ntemplate/pc/rainbow/user/recharge_list.html\r\ntemplate/pc/rainbow/static/css/alone_index.css\r\ntemplate/pc/rainbow/static/css/alone_index.css.map\r\ntemplate/pc/rainbow/static/sass/_headerFooter_alone.scss\r\ntemplate/pc/rainbow/static/sass/alone_index.scss\r\ntemplate/pc/rainbow/static/sass/tpshop.scss\r\nplugins/payment/alipayMobile/alipayMobile.class.php\r\nplugins/payment/tenpay/tenpay.class.php\r\nplugins/payment/unionpay/unionpay.class.php\r\nplugins/payment/weixin/example/notify.php\r\ntemplate/pc/rainbow/static/sass/_headerFooter.scss\r\ntemplate/pc/rainbow/static/sass/_tpshop2.0_index.scss\r\ntemplate/pc/rainbow/static/sass/_details.scss\r\ntemplate/pc/rainbow/static/css/myaccount.css.map\r\ntemplate/pc/rainbow/static/css/tpshop.css.map\r\ntemplate/pc/rainbow/static/sass/_myshopcarlist.scss\r\ntemplate/pc/rainbow/static/sass/_presell.scss\r\napplication/admin/view2/admin/modify_pwd.html\r\napplication/admin/view2/index/about.html\r\napplication/admin/view2/promotion/flash_sale.html\r\napplication/admin/view2/public/left.html\r\nthinkphp/library/think/Controller.php\r\napplication/admin/view2/user/withdrawals.html\r\ntemplate/pc/rainbow/static/config.rb\r\ntemplate/pc/rainbow/static/sass/_index.scss\r\nthinkphp/library/think/view/driver/Think.php\r\napplication/admin/view2/goods/ajaxGoodsList.html\r\napplication/admin/view2/goods/goodsList.html\r\napplication/admin/view2/user/ajaxindex.html\r\npublic/static/js/layer/laydate/laydate.js\r\napplication/admin/model/ShippingArea.php\r\napplication/admin/view/public/header.html\r\npublic/plugins/uploadify/jquery.uploadify.js\r\napplication/admin/view2/admin/log.html\r\napplication/admin/view2/comment/ajax_ask_list.html\r\napplication/admin/view2/comment/ajaxindex.html\r\napplication/admin/view2/comment/ask_list.html\r\napplication/admin/view2/comment/index.html\r\napplication/admin/view2/goods/goodsTypeList.html\r\napplication/admin/view2/order/ajaxdelivery.html\r\napplication/admin/view2/order/delivery_list.html\r\napplication/admin/view2/order/index.html\r\napplication/admin/view2/user/index.html', '1499425716');
